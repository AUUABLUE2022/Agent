#!/usr/bin/env node
/**
 * 一次性准备本地语音识别环境：
 *   1. libvosk.dll   —— vosk 的 Windows 共享库（npm 包不带宽）
 *   2. 中文小模型     —— vosk-model-small-cn-0.22（约 42 MB）
 *
 * 用法：node scripts/setup-model.mjs [--mirror]
 *   --mirror  走 gh-proxy 镜像（国内网络）
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { createWriteStream } from 'node:fs';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SKILL_ROOT = path.resolve(HERE, '..');
const VENDOR = path.join(SKILL_ROOT, 'vendor');

const LIB_ZIP = 'https://gh-proxy.com/https://github.com/alphacep/vosk-api/releases/download/v0.3.45/vosk-win64-0.3.45.zip';
const MODEL_ZIP = 'https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip';

async function download(url, dest) {
  await fs.mkdir(path.dirname(dest), { recursive: true });
  const res = await fetch(url, { redirect: 'follow' });
  if (!res.ok) throw new Error(`下载失败 HTTP ${res.status}: ${url}`);
  await pipeline(Readable.fromWeb(res.body), createWriteStream(dest));
  const st = await fs.stat(dest);
  return st.size;
}

async function unzip(zip, outDir) {
  await fs.mkdir(outDir, { recursive: true });
  // 沙箱下不能用管道 stdio，所以 ignore 掉输出只取退出码
  const r = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${outDir}' -Force`],
    { stdio: 'ignore' }
  );
  if (r.status !== 0) throw new Error(`解压失败，退出码 ${r.status}：${zip}`);
}

async function exists(p) {
  return !!(await fs.stat(p).catch(() => null));
}

async function main() {
  const libDir = path.join(SKILL_ROOT, 'node_modules', 'vosk', 'lib', 'win-x86_64');
  const dll = path.join(libDir, 'libvosk.dll');

  if (await exists(dll)) {
    console.log('✓ libvosk.dll 已存在');
  } else {
    const zip = path.join(VENDOR, 'vosk-win64.zip');
    console.log('↓ libvosk.dll ...');
    const size = await download(LIB_ZIP, zip);
    await unzip(zip, path.join(VENDOR, 'vosk-win64'));
    // 找到 libvosk.dll 并拷进 vosk 期望的位置
    const found = [];
    async function walk(dir) {
      for (const e of await fs.readdir(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) await walk(p);
        else if (e.name.toLowerCase() === 'libvosk.dll') found.push(p);
      }
    }
    await walk(path.join(VENDOR, 'vosk-win64'));
    if (!found.length) throw new Error('压缩包里没找到 libvosk.dll');
    await fs.mkdir(libDir, { recursive: true });
    await fs.copyFile(found[0], dll);
    console.log(`✓ libvosk.dll (${(size / 1048576).toFixed(1)} MB 压缩包)`);
  }

  const modelDir = path.join(SKILL_ROOT, 'models', 'vosk-model-small-cn-0.22');
  if (await exists(path.join(modelDir, 'am', 'final.mdl'))) {
    console.log('✓ 中文模型已存在');
    return;
  }
  const zip = path.join(VENDOR, 'vosk-model-small-cn-0.22.zip');
  console.log('↓ 中文小模型（约 42 MB）...');
  const size = await download(MODEL_ZIP, zip);
  await unzip(zip, path.join(SKILL_ROOT, 'models'));
  console.log(`✓ 模型已解压 (${(size / 1048576).toFixed(1)} MB 压缩包)`);
}

main().catch((e) => {
  console.error('[错误]', e.message);
  process.exit(1);
});
