#!/usr/bin/env node
/**
 * video-learn · 把网页视频变成可读材料
 *
 * 子命令：
 *   info    <url>            元信息（标题、UP 主、时长、分P）
 *   frames  <url>            关键帧 → 带时间戳的联系表（contact sheet）
 *   audio   <url>            下载音频流（m4a）
 *   asr     <url>            本地语音识别（vosk 中文小模型）→ 带时间码逐字稿
 *   subs    <url>            下载字幕（需登录 cookie）
 *   report  <url>            汇总成 video.md
 *
 * 用法示例：
 *   node scripts/video.mjs frames "https://www.bilibili.com/video/BV1REx46NEc4/" --every 45
 *   node scripts/video.mjs asr "BV1REx46NEc4" --max-seconds 180
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { createWriteStream } from 'node:fs';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const SKILL_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const HEADERS = {
  'user-agent': UA,
  referer: 'https://www.bilibili.com/',
  accept: 'application/json, text/plain, */*',
};

// ---------------------------------------------------------------- 参数与工具

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        args[key] = next;
        i++;
      } else {
        args[key] = true;
      }
    } else {
      args._.push(a);
    }
  }
  return args;
}

const fmtTime = (s) => {
  const n = Math.max(0, Math.round(s));
  const h = Math.floor(n / 3600);
  const m = Math.floor((n % 3600) / 60);
  const sec = n % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(sec).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
};

async function getJSON(url, cookie) {
  const headers = { ...HEADERS };
  if (cookie) headers.cookie = cookie;
  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
  const json = await res.json();
  if (json.code !== 0) throw new Error(`B站接口返回 ${json.code}: ${json.message} (${url})`);
  return json.data;
}

async function download(url, dest, cookie, tries = 3) {
  const headers = { ...HEADERS };
  if (cookie) headers.cookie = cookie;
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(url, { headers });
      if (!res.ok) throw new Error(`下载失败 HTTP ${res.status}`);
      await fs.mkdir(path.dirname(dest), { recursive: true });
      await pipeline(Readable.fromWeb(res.body), createWriteStream(dest));
      const st = await fs.stat(dest);
      if (st.size === 0) throw new Error('下到 0 字节');
      return st.size;
    } catch (e) {
      lastErr = e;
      console.error(`[download] 第 ${i + 1}/${tries} 次失败：${e.message || e}`);
      await new Promise((r) => setTimeout(r, 1500 * (i + 1)));
    }
  }
  throw new Error(`下载失败（重试 ${tries} 次）：${lastErr?.message || lastErr}`);
}

/** 下载图片并校验是不是真 JPEG；坏了就删掉重下一次 */
async function ensureImage(url, dest) {
  const valid = async () => {
    try {
      const b = await fs.readFile(dest);
      return b.length > 2000 && b[0] === 0xff && b[1] === 0xd8;
    } catch {
      return false;
    }
  };
  if (await valid()) return;
  await fs.rm(dest, { force: true });
  await download(url, dest);
  if (!(await valid())) throw new Error(`雪碧图不是有效 JPEG：${path.basename(dest)}`);
}

// ---------------------------------------------------------------- 解析输入
function extractBvid(input) {
  const m = /BV[0-9A-Za-z]{10}/.exec(input);
  if (m) return m[0];
  const av = /av(\d+)/i.exec(input);
  if (av) return { aid: Number(av[1]) };
  return null;
}

async function resolveTarget(input) {
  // b23.tv 短链：跟随重定向拿到真实 URL
  if (/b23\.tv|bili2233/.test(input)) {
    const res = await fetch(input, { headers: HEADERS, redirect: 'follow' });
    input = res.url || input;
  }
  const id = extractBvid(input);
  if (!id) throw new Error(`无法从 ${input} 解析出 BV 号`);
  const q = typeof id === 'string' ? `bvid=${id}` : `aid=${id.aid}`;
  const data = await getJSON(`https://api.bilibili.com/x/web-interface/view?${q}`);
  return data;
}

function pickPage(data, pageArg) {
  const pages = data.pages || [];
  const idx = pageArg ? Number(pageArg) - 1 : 0;
  const page = pages[idx] || pages[0];
  if (!page) throw new Error('该视频没有可用的分P信息');
  return page;
}

function outDirFor(args, data) {
  const base = args.out ? path.resolve(args.out) : path.join(process.cwd(), 'video-notes', data.bvid);
  return base;
}

/** 从文本里取第一行非注释内容，兼容 `SESSDATA=xxx` 与裸值 */
function pickCookieValue(raw) {
  const line = String(raw)
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter((s) => s && !s.startsWith('#'))
    .pop();
  if (!line) return null;
  return line.replace(/^SESSDATA\s*=\s*/i, '').replace(/;+$/, '');
}

function cookieFrom(args) {
  // 1) 显式参数
  if (args.cookie) return `SESSDATA=${args.cookie}`;
  if (args['cookie-file']) {
    const v = pickCookieValue(require('node:fs').readFileSync(path.resolve(args['cookie-file']), 'utf8'));
    if (v) return `SESSDATA=${v}`;
  }
  // 2) 环境变量
  if (process.env.BILI_SESSDATA) return `SESSDATA=${process.env.BILI_SESSDATA}`;
  // 3) 约定文件：当前目录 → 用户 DSH 目录
  for (const p of [path.join(process.cwd(), 'bili-sessdata.txt'), path.join(process.env.USERPROFILE || '', '.dsh', 'bili-sessdata.txt')]) {
    try {
      const v = pickCookieValue(require('node:fs').readFileSync(p, 'utf8'));
      if (v) return `SESSDATA=${v}`;
    } catch {
      /* 没有就算了 */
    }
  }
  return null;
}

// ---------------------------------------------------------------- info

async function cmdInfo(args) {
  const data = await resolveTarget(args._[0]);
  const page = pickPage(data, args.page);
  const out = {
    标题: data.title,
    简介: (data.desc || '').trim(),
    UP主: data.owner?.name,
    时长秒: page.duration,
    时长: fmtTime(page.duration),
    分P数: (data.pages || []).length,
    当前P: page.page,
    当前P标题: page.part,
    cid: page.cid,
    aid: data.aid,
    bvid: data.bvid,
    分区: data.tname || undefined,
    发布时间: new Date(data.pubdate * 1000).toISOString().slice(0, 19).replace('T', ' '),
    播放: data.stat?.view,
    点赞: data.stat?.like,
    收藏: data.stat?.favorite,
    弹幕: data.stat?.danmaku,
  };
  console.log(JSON.stringify(out, null, 2));
  const dir = outDirFor(args, data);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(path.join(dir, 'meta.json'), JSON.stringify({ ...out, pages: data.pages }, null, 2), 'utf8');
  console.error(`\n[info] 已写入 ${path.join(dir, 'meta.json')}`);
}

// ---------------------------------------------------------------- frames

async function cmdFrames(args) {
  const sharp = (await import('sharp')).default;
  const data = await resolveTarget(args._[0]);
  const page = pickPage(data, args.page);
  const dir = outDirFor(args, data);
  const spriteDir = path.join(dir, 'sprites');
  const framesDir = path.join(dir, 'frames');

  const shot = await getJSON(
    `https://api.bilibili.com/x/player/videoshot?aid=${data.aid}&cid=${page.cid}&index=1`
  );
  const images = (shot.image || []).map((u) => (u.startsWith('//') ? 'https:' + u : u));
  if (!images.length) throw new Error('该视频没有可用的缩略图雪碧图（videoshot）');

  const xLen = shot.img_x_len || 10;
  const yLen = shot.img_y_len || 10;
  const stamps = shot.index || [];
  const perframe = xLen * yLen;
  const total = stamps.length;
  const duration = page.duration || stamps[total - 1] || 0;

  // 采样间隔：优先用 --every，否则按目标张数自适应
  const maxFrames = Number(args.max || 48);
  const every = Number(args.every || Math.max(5, Math.ceil(duration / maxFrames)));

  const wanted = [];
  for (let t = 0; t < total; t++) {
    const ts = stamps[t];
    if (ts === undefined) continue;
    if (wanted.length === 0 || ts - wanted[wanted.length - 1].ts >= every) {
      wanted.push({ ts, idx: t });
    }
  }
  if (wanted.length > maxFrames) wanted.length = maxFrames;

  // 下载用到的雪碧图
  await fs.mkdir(spriteDir, { recursive: true });
  await fs.mkdir(framesDir, { recursive: true });

  const needSprites = [...new Set(wanted.map((w) => Math.floor(w.idx / perframe)))];
  const spriteFiles = new Map();
  for (const si of needSprites) {
    const url = images[si];
    if (!url) continue;
    const dest = path.join(spriteDir, `sprite-${String(si + 1).padStart(2, '0')}.jpg`);
    await ensureImage(url, dest);
    spriteFiles.set(si, dest);
  }

  // 单帧尺寸 = 雪碧图尺寸 / 网格
  const firstSprite = [...spriteFiles.values()][0];
  const md = await sharp(firstSprite).metadata();
  const fw = Math.floor(md.width / xLen);
  const fh = Math.floor(md.height / yLen);

  // 裁出每个采样帧
  const cells = [];
  for (const w of wanted) {
    const si = Math.floor(w.idx / perframe);
    const local = w.idx % perframe;
    const col = local % xLen;
    const row = Math.floor(local / xLen);
    const file = path.join(framesDir, `t${String(Math.round(w.ts)).padStart(5, '0')}.jpg`);
    await sharp(spriteFiles.get(si))
      .extract({ left: col * fw, top: row * fh, width: fw, height: fh })
      .resize(480, 270, { fit: 'cover' })
      .jpeg({ quality: 82 })
      .toFile(file);
    cells.push({ ts: w.ts, file });
  }

  // 拼联系表
  const cols = Number(args.cols || 3);
  const rows = Number(args.rows || 3);
  const perSheet = cols * rows;
  const labelH = 24;
  const sheetWidth = cols * 480;
  const sheetHeight = rows * (270 + labelH);
  const sheets = [];

  for (let s = 0; s * perSheet < cells.length; s++) {
    const group = cells.slice(s * perSheet, s * perSheet + perSheet);
    const composite = [];
    for (let i = 0; i < group.length; i++) {
      const cx = (i % cols) * 480;
      const cy = Math.floor(i / cols) * (270 + labelH);
      composite.push({ input: group[i].file, left: cx, top: cy + labelH });
      const label = Buffer.from(
        `<svg width="${480}" height="${labelH}" xmlns="http://www.w3.org/2000/svg">
           <rect width="480" height="${labelH}" fill="#111"/>
           <text x="10" y="17" font-family="Segoe UI, Arial, sans-serif" font-size="14" fill="#7ee787">${fmtTime(
             group[i].ts
           )}</text>
           <text x="80" y="17" font-family="Segoe UI, Arial, sans-serif" font-size="12" fill="#888">#${s * perSheet + i + 1}</text>
         </svg>`
      );
      composite.push({ input: label, left: cx, top: cy });
    }
    const sheetFile = path.join(dir, `sheet-${String(s + 1).padStart(2, '0')}.png`);
    await sharp({
      create: {
        width: sheetWidth,
        height: sheetHeight,
        channels: 3,
        background: { r: 17, g: 17, b: 17 },
      },
    })
      .composite(composite)
      .png()
      .toFile(sheetFile);
    sheets.push({ file: sheetFile, from: group[0].ts, to: group[group.length - 1].ts, count: group.length });
  }

  const manifest = {
    bvid: data.bvid,
    title: data.title,
    cid: page.cid,
    duration,
    frameSize: [fw, fh],
    spriteGrid: [xLen, yLen],
    sampleEverySeconds: every,
    frames: cells.map((c, i) => ({ n: i + 1, ts: c.ts, time: fmtTime(c.ts), file: path.relative(dir, c.file) })),
    sheets: sheets.map((s) => ({ ...s, file: path.relative(dir, s.file) })),
  };
  await fs.writeFile(path.join(dir, 'frames.json'), JSON.stringify(manifest, null, 2), 'utf8');

  console.log(
    JSON.stringify(
      {
        视频时长: fmtTime(duration),
        采样间隔秒: every,
        采样帧数: cells.length,
        联系表: sheets.map((s) => ({
          file: s.file,
          covers: `${fmtTime(s.from)} - ${fmtTime(s.to)}`,
          frames: s.count,
        })),
      },
      null,
      2
    )
  );
  console.error(`\n[frames] 输出目录 ${dir}`);
}

// ---------------------------------------------------------------- audio

async function cmdAudio(args) {
  const data = await resolveTarget(args._[0]);
  const page = pickPage(data, args.page);
  const dir = outDirFor(args, data);
  const q = args.quality || 'mid';

  const pu = await getJSON(
    `https://api.bilibili.com/x/player/playurl?avid=${data.aid}&cid=${page.cid}&qn=64&fnval=4048&fourk=1`
  );
  const audios = (pu.dash?.audio || []).slice().sort((a, b) => a.bandwidth - b.bandwidth);
  if (!audios.length) throw new Error('没有可用的 DASH 音频流（可能需要登录 cookie）');
  const chosen = q === 'best' ? audios[audios.length - 1] : q === 'low' ? audios[0] : audios[Math.floor(audios.length / 2)];

  const dest = path.join(dir, 'audio.m4a');
  const size = await download(chosen.baseUrl, dest);
  console.log(
    JSON.stringify(
      {
        文件: dest,
        码率kbps: Math.round(chosen.bandwidth / 1000),
        编码: chosen.codecs,
        大小MB: (size / 1024 / 1024).toFixed(1),
        时长: fmtTime(page.duration),
      },
      null,
      2
    )
  );
}

// ---------------------------------------------------------------- subs

async function cmdSubs(args) {
  const data = await resolveTarget(args._[0]);
  const page = pickPage(data, args.page);
  const dir = outDirFor(args, data);
  const cookie = cookieFrom(args);
  if (args.verbose) {
    console.error(
      `[subs] cookie：${cookie ? `已提供（${cookie.slice(0, 22)}…）` : '未提供'}；文件：${
        args['cookie-file'] || '（自动查找 bili-sessdata.txt）'
      }`
    );
  }

  const p2 = await getJSON(
    `https://api.bilibili.com/x/player/v2?aid=${data.aid}&cid=${page.cid}`,
    cookie
  );
  const list = p2.subtitle?.subtitles || [];
  if (!list.length) {
    const why = p2.need_login_subtitle
      ? '该视频的字幕需要登录态：把浏览器里的 SESSDATA 传到 --cookie 或环境变量 BILI_SESSDATA 再试'
      : '该视频没有开放字幕';
    console.error(`[subs] 没拿到字幕：${why}`);
    process.exitCode = 2;
    return;
  }
  const track = list.find((s) => /zh|ai-zh/.test(s.lan)) || list[0];
  const url = track.subtitle_url.startsWith('//') ? 'https:' + track.subtitle_url : track.subtitle_url;
  const body = await getJSON(url);
  const items = body.body || [];

  const lines = items.map((it) => `[${fmtTime(it.from)}] ${it.content}`);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(path.join(dir, 'subtitle.json'), JSON.stringify(items, null, 2), 'utf8');
  await fs.writeFile(path.join(dir, 'transcript.txt'), `${data.title}\n\n${lines.join('\n')}\n`, 'utf8');
  console.log(
    JSON.stringify({ 语言: track.lan_doc, 条数: items.length, 文件: path.join(dir, 'transcript.txt') }, null, 2)
  );
}

// ---------------------------------------------------------------- asr

/** 解析 wav 头，返回 data 块起点与该块长度 */
function readWavData(buf) {
  let off = 12;
  while (off + 8 <= buf.length) {
    const id = buf.toString('ascii', off, off + 4);
    const size = buf.readUInt32LE(off + 4);
    if (id === 'data') return { start: off + 8, size };
    off += 8 + size + (size % 2);
  }
  throw new Error('wav 里找不到 data 块');
}

async function cmdAsr(args) {
  const vosk = require('vosk');
  const ffmpeg = require('@ffmpeg-installer/ffmpeg').path;

  const data = await resolveTarget(args._[0]);
  const page = pickPage(data, args.page);
  const dir = outDirFor(args, data);
  const audioPath = args.audio ? path.resolve(args.audio) : path.join(dir, 'audio.m4a');
  const modelPath = args.model ? path.resolve(args.model) : path.join(SKILL_ROOT, 'models', 'vosk-model-small-cn-0.22');

  // 1. 没有音频就先下
  try {
    await fs.access(audioPath);
  } catch {
    console.error('[asr] 本地没有音频，先下载…');
    const pu = await getJSON(
      `https://api.bilibili.com/x/player/playurl?avid=${data.aid}&cid=${page.cid}&qn=64&fnval=4048&fourk=1`
    );
    const audios = (pu.dash?.audio || []).slice().sort((a, b) => a.bandwidth - b.bandwidth);
    if (!audios.length) throw new Error('没有可用音频流');
    await download(audios[Math.floor(audios.length / 2)].baseUrl, audioPath);
  }

  await fs.access(path.join(modelPath, 'am', 'final.mdl')).catch(() => {
    throw new Error(`找不到模型：${modelPath}\n先跑一次 node scripts/setup-model.mjs`);
  });

  // 2. 转 16k 单声道 wav（用 spawnSync + stdio ignore，沙箱下不能用管道）
  const wavPath = args.wav ? path.resolve(args.wav) : path.join(dir, 'audio-16k.wav');
  const maxSec = args['max-seconds'] ? Number(args['max-seconds']) : 0;
  const ffArgs = ['-y', '-i', audioPath, '-ar', '16000', '-ac', '1', '-f', 'wav'];
  if (maxSec) ffArgs.push('-t', String(maxSec));
  ffArgs.push(wavPath);
  console.error('[asr] ffmpeg 转码…');
  const ff = spawnSync(ffmpeg, ffArgs, { stdio: 'ignore' });
  if (ff.status !== 0) throw new Error(`ffmpeg 转码失败，退出码 ${ff.status}`);

  // 3. vosk 流式识别
  const buf = await fs.readFile(wavPath);
  const { start, size } = readWavData(buf);
  const pcm = buf.subarray(start, start + size);
  const totalSec = Math.floor(pcm.length / 32000);

  // vosk 的 C++ 层用窄字符路径，含中文的绝对路径会报 "does not contain model files"。
  // 绕法：先 chdir 到模型目录，再用相对路径 "." 加载。
  const cwd0 = process.cwd();
  process.chdir(modelPath);
  let model;
  try {
    vosk.setLogLevel(-1);
    model = new vosk.Model('.');
  } finally {
    process.chdir(cwd0);
  }
  const rec = new vosk.Recognizer({ model, sampleRate: 16000 });
  rec.setWords(true);

  const segs = [];
  const CHUNK = 16000 * 2 * 2; // 2 秒
  let lastReport = 0;
  // vosk 中文结果按词加空格，去掉 CJK 之间的空格更像人话
  const tidy = (s) => s.replace(/(?<=[\u4e00-\u9fff，。、？！；：])\s+(?=[\u4e00-\u9fff，。、？！；：])/g, '').trim();
  for (let off = 0; off < pcm.length; off += CHUNK) {
    const slice = pcm.subarray(off, Math.min(off + CHUNK, pcm.length));
    if (!rec.acceptWaveform(slice)) continue;
    const r = rec.result();
    const text = tidy(r.text || '');
    const t = r.result?.[0]?.start ?? off / 32000;
    if (text) segs.push({ t, text });
    const done = Math.floor(off / 32000);
    if (done - lastReport >= 60) {
      lastReport = done;
      console.error(`[asr] ${fmtTime(done)} / ${fmtTime(totalSec)}，已吐 ${segs.length} 段`);
    }
  }
  const tail = rec.finalResult();
  if (tail.text && tail.text.trim()) segs.push({ t: totalSec, text: tidy(tail.text) });
  rec.free();
  model.free();

  // 4. 落盘
  const lines = segs.map((s) => `[${fmtTime(s.t)}] ${s.text}`);
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(path.join(dir, 'asr.json'), JSON.stringify(segs, null, 2), 'utf8');
  await fs.writeFile(path.join(dir, 'transcript.txt'), `${data.title}\n\n${lines.join('\n')}\n`, 'utf8');
  console.log(
    JSON.stringify(
      {
        模型: path.basename(modelPath),
        音频时长: fmtTime(totalSec),
        段落数: segs.length,
        字数: lines.join('').length,
        文件: path.join(dir, 'transcript.txt'),
        前五段: lines.slice(0, 5),
      },
      null,
      2
    )
  );
}

// ---------------------------------------------------------------- report

async function cmdReport(args) {
  const data = await resolveTarget(args._[0]);
  const page = pickPage(data, args.page);
  const dir = outDirFor(args, data);
  const exists = async (p) => !!(await fs.stat(p).catch(() => null));

  const parts = [];
  parts.push(`# ${data.title}`);
  parts.push('');
  parts.push(`- UP 主：${data.owner?.name}`);
  parts.push(`- 时长：${fmtTime(page.duration)}`);
  parts.push(`- 播放 / 点赞 / 收藏：${data.stat?.view} / ${data.stat?.like} / ${data.stat?.favorite}`);
  parts.push(`- BV：${data.bvid}　cid：${page.cid}`);
  if (data.desc) {
    parts.push('');
    parts.push('## 简介');
    parts.push('');
    parts.push(data.desc.trim());
  }

  const subFile = path.join(dir, 'transcript.txt');
  if (await exists(subFile)) {
    parts.push('');
    parts.push('## 转写（字幕）');
    parts.push('');
    parts.push('```');
    parts.push((await fs.readFile(subFile, 'utf8')).slice(0, 60000));
    parts.push('```');
  }

  const frameFile = path.join(dir, 'frames.json');
  if (await exists(frameFile)) {
    const m = JSON.parse(await fs.readFile(frameFile, 'utf8'));
    parts.push('');
    parts.push('## 关键帧索引');
    parts.push('');
    parts.push(`共 ${m.frames.length} 帧，采样间隔 ${m.sampleEverySeconds} 秒。联系表：`);
    for (const s of m.sheets) parts.push(`- ${s.file}（${fmtTime(s.from)} – ${fmtTime(s.to)}）`);
    parts.push('');
    parts.push('| # | 时间 | 文件 |');
    parts.push('| --- | --- | --- |');
    for (const f of m.frames) parts.push(`| ${f.n} | ${f.time} | ${f.file} |`);
  }

  parts.push('');
  parts.push('## 已知边界');
  parts.push('');
  parts.push('- 没有登录 cookie 时拿不到字幕，此时只能依据关键帧画面推断内容，听不到旁白。');
  parts.push('- 关键帧来自 B 站缩略图雪碧图，分辨率约 160×90，仅够读屏幕上的大字/结构。');
  parts.push('- 需要逐字稿请配 ASR（当前技能未内置）。');

  const out = path.join(dir, 'video.md');
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(out, parts.join('\n') + '\n', 'utf8');
  console.log(out);
}

// ---------------------------------------------------------------- main

const COMMANDS = { info: cmdInfo, frames: cmdFrames, audio: cmdAudio, asr: cmdAsr, subs: cmdSubs, report: cmdReport };

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = args._[0];
  if (!cmd || !COMMANDS[cmd]) {
    console.error(`用法：node scripts/video.mjs <${Object.keys(COMMANDS).join('|')}> <url> [选项]`);
    process.exit(2);
  }
  const target = args._[1];
  if (!target) {
    console.error('缺少视频 URL 或 BV 号');
    process.exit(2);
  }
  args._ = [target];
  await COMMANDS[cmd](args);
}

main().catch((e) => {
  console.error(`[错误] ${e.message}`);
  process.exit(1);
});
