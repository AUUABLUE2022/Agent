﻿# 一键安装 video-agent
# 用法：powershell -ExecutionPolicy Bypass -File .\install.ps1 [-Target <目录>] [-SkipModel]
param(
  [string]$Target = (Join-Path $env:USERPROFILE '.dsh\skills\video-agent'),
  [switch]$SkipModel
)

$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
Write-Host ""
Write-Host "video-agent 安装" -ForegroundColor Cyan
Write-Host "  源目录：$src"
Write-Host "  目标：  $Target"
Write-Host ""

# 1) 找 node
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) {
  $guess = Join-Path $env:LOCALAPPDATA 'Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe'
  if (Test-Path $guess) { $node = $guess }
}
if (-not $node) {
  Write-Host "找不到 node。请先装 Node 20+，或改用 DSH 自带的 node（在 DSH 安装目录的 resources\runtime\... 下）。" -ForegroundColor Red
  exit 1
}
Write-Host "[1/5] node：$node" -ForegroundColor Green
& $node -v

# 2) 复制文件（排除依赖与下载缓存）
Write-Host "[2/5] 复制文件…" -ForegroundColor Green
New-Item -ItemType Directory -Force -Path $Target | Out-Null
$exclude = @('node_modules', 'models', 'vendor', '.git')
Get-ChildItem $src -Force | Where-Object { $exclude -notcontains $_.Name } | ForEach-Object {
  Copy-Item $_.FullName -Destination $Target -Recurse -Force
}

# 3) 装依赖
Write-Host "[3/5] 安装依赖（sharp / vosk / ffmpeg，约 240 MB）…" -ForegroundColor Green
Push-Location $Target
try {
  $npm = (Get-Command npm -ErrorAction SilentlyContinue).Source
  if ($npm) {
    & $npm install --omit=dev --no-audit --no-fund
  } else {
    $pnpm = (Get-Command pnpm -ErrorAction SilentlyContinue).Source
    if (-not $pnpm) {
      $pnpmMjs = Join-Path $env:LOCALAPPDATA 'Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\pnpm\bin\pnpm.mjs'
      if (Test-Path $pnpmMjs) {
        & $node $pnpmMjs install --node-linker=hoisted --prod
      } else {
        throw "找不到 npm / pnpm，请手动在 $Target 里执行 npm install"
      }
    } else {
      & $pnpm install --prod
    }
  }
} finally {
  Pop-Location
}

# 4) 模型
if ($SkipModel) {
  Write-Host "[4/5] 跳过模型下载（之后可跑 node scripts/setup-model.mjs）" -ForegroundColor Yellow
} else {
  Write-Host "[4/5] 下载语音模型（约 42 MB，可能较慢）…" -ForegroundColor Green
  & $node (Join-Path $Target 'scripts\setup-model.mjs')
}

# 5) 自检
Write-Host "[5/5] 自检" -ForegroundColor Green
& $node (Join-Path $Target 'scripts\doctor.mjs')

Write-Host ""
Write-Host "装好了。在 DSH 里直接丢一个视频链接，或输入 /video-learn。" -ForegroundColor Cyan
