﻿# 注册 Windows 任务计划：让 video-agent 自己按时跑
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\register-task.ps1 -Hours 6
#   powershell -ExecutionPolicy Bypass -File .\register-task.ps1 -Unregister
param(
  [string]$AgentDir = (Split-Path $PSScriptRoot -Parent),
  [int]$Hours = 6,
  [string]$TaskName = 'VideoAgent',
  [switch]$Unregister
)

$ErrorActionPreference = 'Stop'

if ($Unregister) {
  if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "已注销任务 $TaskName" -ForegroundColor Green
  } else {
    Write-Host "没有找到任务 $TaskName" -ForegroundColor Yellow
  }
  exit 0
}

# 找 node：PATH → DSH 自带
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) {
  $guess = Join-Path $env:LOCALAPPDATA 'Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe'
  if (Test-Path $guess) { $node = $guess }
}
if (-not $node) { throw "找不到 node，请先装 Node 20+ 或改用 DSH 自带的 node" }

$agent = Join-Path $AgentDir 'scripts\agent.mjs'
if (-not (Test-Path $agent)) { throw "找不到 $agent，-AgentDir 指对了吗？" }

$logDir = Join-Path $AgentDir 'triggers'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$log = Join-Path $logDir 'agent.log'

$inner = "& '$node' '$agent' run *>> '$log'"
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -Command `"$inner`""
$trigger = New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(2)) -RepetitionInterval (New-TimeSpan -Hours $Hours) -RepetitionDuration ([TimeSpan]::MaxValue)
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -ExecutionTimeLimit (New-TimeSpan -Hours 2)

Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Description 'video-agent：定时巡查 B 站新视频并归档笔记' -Force | Out-Null

Write-Host "已注册任务 $TaskName：每 $Hours 小时跑一次" -ForegroundColor Green
Write-Host "  跑一次：  Start-ScheduledTask -TaskName $TaskName"
Write-Host "  看日志：  Get-Content '$log' -Tail 30"
Write-Host "  注销：    .\register-task.ps1 -Unregister"
