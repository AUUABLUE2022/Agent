# 发布清单

目录已经是可直接上传的仓库内容。下面是照抄就行的一页。

## 仓库信息

**名称**：`video-agent`
**一句话**：会看视频的 Agent——自己发现新视频、抓关键帧、跑本地转写、归类归档、失败重试，带三种触发器。
**描述（GitHub/Gitee 填这个）**：

> An autonomous agent that actually watches videos: timestamped keyframe contact sheets + offline Chinese speech-to-text + a self-driving "follow & archive" loop with scheduled/daemon/DSH triggers. DSH skill bundle, Node only.

**Topics / 标签**：

```
deepseek-harness  dsh  skill  agent  autonomous  bilibili  speech-to-text  vosk  video-summary  llm-tools
```

**License**：MIT

## 上传（Gitee，网络可达）

```powershell
cd release\video-agent
git init
git add .
git commit -m "feat: video-agent v1.0.0 - 从 skill 升级为带触发器的自主 agent"
git branch -M main
git remote add origin https://gitee.com/<你的用户名>/video-agent.git
git push -u origin main
git tag v1.0.0
git push origin v1.0.0
```

GitHub（需要先解决网络）：

```powershell
git remote add origin https://github.com/<你的用户名>/video-agent.git
git push -u origin main --tags
```

## Release 文案（可直接粘贴）

**v1.0.0 — 从 Skill 升级成 Agent**

v0.3 是个"能力包"：你丢链接，它给材料。v1.0 加了自主循环和触发器，现在它能自己开工。

新增：

- `agent.mjs`：`run` / `watch` / `status` 三个入口，状态机 + 重试 + 放弃，全程幂等
- **三种触发器**：Windows 任务计划（不需要开着任何东西）、常驻循环、DSH 定时（这条带模型）
- **自动版笔记**：模板 + 时间轴 + 联系表 + 一份「待校订」清单，明确标出哪里不确定
- `doctor.mjs` 自检：node / 依赖 / libvosk / 模型 / B 站接口，缺什么告诉你修什么
- 修了两个真 bug：`sharp(url)` 的同步抛错、`retry` 状态的条目不会重新排队

实测：一条 21 分钟的讲义，155 秒跑完 info → 20 帧 → 转写 → 写笔记 → 归档 → 更新索引。

已知限制：缩略图 160×90 读不清小字；小模型专有名词识别差；关键词分类会漏（真实案例：「正交试验设计」被归进「待分类」）；任务计划那条路没有模型，只出模板笔记。

附件：`video-agent-1.0.0.zip`（源码，不含 node_modules 与模型）

## 发布前自查（都已过）

- [x] `node scripts/doctor.mjs` 全绿
- [x] 自主流水线真实跑通：155 秒产出一篇归档笔记
- [x] `install.ps1` 从零装成功（25.5 秒），`doctor` 复检通过
- [x] 失败路径验证过：缺依赖 → 进 retry → 修好后补跑成功
- [x] README 有实测数据，不是估计
- [x] 边界写得直白，不吹"完美转写"
- [x] `.gitignore` 排掉 `node_modules/`、`models/`、`bili-sessdata.txt`、`triggers/agent.log`
- [x] 没有把任何 cookie / 密钥带进包里

## 发布后可以做的

1. 在干净机器上 `git clone` → `install.ps1` → `agent.mjs run`，验证陌生人视角能不能跑通——这一步最容易暴露 README 的坑。
2. 把"合集之外抓不到"补掉（需要 wbi 签名 + cookie）。
3. 想上 DSH 插件市场，得再包一层 cordis 插件（`package.json` + `cordis.patch.yml` + 图标 + 双语 README），这份代码可作为 `resources` 原样复用。
