---
name: video-learn
description: 把网页视频（B 站为主）变成可读材料：元信息、带时间戳的关键帧联系表、本地语音转写、音频流、字幕，据此"看"完视频并做笔记；还能定时巡查一个 UP 主并归档。
whenToUse: 用户给了视频链接并要求观看/总结/学习/复刻，或需要核对某个时间点讲了什么，或要维护一个"追更 + 归档"的课程库。
---

# 看视频 / 听视频

你可以**看**画面、也可以**听**声音（本地离线转写，不联网、不调 API）。按信息密度从高到低用：

1. **字幕**（最准）——多数 B 站视频需登录态才开放，见「登录态」一节。
2. **本地语音转写**（一定有，质量中等）——vosk 中文小模型离线跑，给的是"大意可信、逐字不可信"的稿子。
3. **关键帧联系表**（一定有）——按间隔采样拼成带时间码的图，教程/演示类视频的信息量主要在这里。
4. **音频流**（可选）——留作外部 ASR 或用户自用。

## 先找 node

脚本要用 Node 20+。优先用 DSH 自带的（Windows 默认位置）：

```powershell
$node = "<DSH 安装目录>\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
```

找不到就退回 PATH 里的 `node`。先跑 `& $node .\scripts\doctor.mjs` 自检，它会告诉你缺什么。

## 命令

```powershell
& $node .\scripts\video.mjs info    "<url 或 BV>"  [--page N] [--out 目录]
& $node .\scripts\video.mjs frames  "<url 或 BV>"  [--every 秒] [--max 张数] [--cols 4] [--rows 3] [--out 目录]
& $node .\scripts\video.mjs asr     "<url 或 BV>"  [--max-seconds N] [--audio 本地文件] [--model 模型目录] [--out 目录]
& $node .\scripts\video.mjs audio   "<url 或 BV>"  [--quality low|mid|best] [--out 目录]
& $node .\scripts\video.mjs subs    "<url 或 BV>"  [--cookie-file 文件] [--verbose] [--out 目录]
& $node .\scripts\video.mjs report  "<url 或 BV>"  [--out 目录]
```

- `--out` 默认 `<当前目录>/video-notes/<BV号>/`。
- `frames` 产出 `sheet-NN.png`（默认 4×3，每格带 `mm:ss`）与 `frames.json`。
- `asr` 产出 `transcript.txt`（`[mm:ss] 文本`）与 `asr.json`；本地没音频会先自动下载。
- `subs` 无登录态时以退出码 2 结束并说明原因，**是预期行为，别连试三次**。

## 标准流程

1. `info`：标题、时长、分P、cid。先判断类型——教程/演示靠画面，访谈/口播靠转写。
2. 采样：教程类 `--every 30 --max 96`；访谈类 `--every 60 --max 48`；长视频先粗后精。
3. `read_image` 逐张看 `sheet-*.png`，**同时读时间码**，把结论锚到秒。
4. 要逐字稿：先 `subs`（需 cookie）；拿不到就 `asr`。50 分钟音频约跑 15 分钟，**丢后台**。
5. 写笔记：按时间轴分节，每节「讲了什么 + 画面证据 + 时间点」。转写与画面冲突时**以画面为准**。

## 转写的可信度（重要）

- 小模型 + 背景音乐 + 快语速 → 专有名词几乎必错（实测把 DSH 听成"定性蚶子"、Harness 听成"哈里斯"）。
- 只能用于：判断大意、定位话题切换、给笔记加时间锚点。
- **绝不能**当逐字稿引用；引用原话必须来自 `subs`。
- 想要更好质量：换更大的模型，或接云端 ASR。

## 登录态（只有拿官方字幕才需要）

优先级：`--cookie-file` → 环境变量 `BILI_SESSDATA` → 当前目录 `bili-sessdata.txt` → `~/.dsh/bili-sessdata.txt`。

文件里写 `SESSDATA=xxx` 或裸值都行，`#` 开头当注释。**不要让用户在对话里粘贴 SESSDATA**（会留在会话记录里）。

拿不到字幕是常态，先走 `asr` 或关键帧，别反复重试 `subs`。

## 自主模式（推荐先试这个）

这个包不只是"你问一句它答一句"，它有自己的循环：

```powershell
& $node .\scripts\agent.mjs run    --limit 2      # 跑一轮：发现→抓→转写→归档
& $node .\scripts\agent.mjs status                 # 队列长什么样
& $node .\scripts\agent.mjs watch   --interval 120 # 常驻，每 2 小时一轮
```

`agent.mjs` 自己判断：哪些是新视频、哪些上次失败了要重试、哪条够格归档。状态在 `<课程库>/.agent-state.json`。

**它产出的笔记是"模板版"**：结构、证据、时间轴都对，但没有解读，末尾有一节「待校订」。你的活儿就是把那节改掉——所以收到 `done` 之后，**一定要读 `sheet-*.png` 再动笔**，不要只依据转写。

触发器有四种，见 `triggers/README.md`：任务计划（无模型）、常驻循环、DSH 定时（带模型）、手动。

## 巡查与归档（课程库）

```powershell
& $node .\scripts\watch.mjs --mid <UP 的 mid> --vault "<课程库目录>" [--limit 3] [--every 60] [--asr] [--dry-run] [--force]
```

- **首次运行只建基线**：把已有视频全标成已读，只处理最新 `--limit` 条；之后只处理增量（幂等）。
- 产出目录：`_inbox/<BV>/`（meta.json、`sheet-*.png`、`draft.md`、可选 transcript）、`学科/<学科>/`、`index.md`、`.state.json`、`subjects.json`。
- `subjects.json` 是「学科 → 标题关键词」表，脚本按它做初判；**最终归类由模型判断**。
- 列表走「合集 / 系列」接口（`seasons_series_list` + `seasons_archives_list`），因为 `space/arc/search` 和 wbi 版在无登录态下会被风控（-352/-412/-799）。代价：**不在任何合集的散视频会漏**。
- 定时用 DSH 的 `schedule_create`，prompt 里写清三步：跑 watch → 读 draft 与联系表 → 写笔记并更新 index。

## 环境坑（改脚本前先看）

- **含中文的路径会让 vosk 报 "does not contain model files"**：它的 C++ 层用窄字符打开文件。脚本已用 `process.chdir(模型目录)` + `new vosk.Model('.')` 绕开，别改回绝对路径。
- 沙箱里 **Node 的 `child_process` 用管道 stdio 会 EPERM**：`spawnSync` 一律 `stdio: 'ignore'`。
- 系统 `curl` / Python 的 HTTPS 在某些受限环境下会失败；本脚本全用 Node 内置 `fetch`。
- 下载偶发 `fetch failed`，`download()` 已内置 3 次重试。

## 边界

- 缩略图单帧约 160×90，只够读大字、界面结构、代码轮廓。
- 下载的帧/音频留在工作区，任务结束问用户要不要保留。
- 弹幕、评论不算视频内容，别混进笔记。
