#!/usr/bin/env node
/**
 * watch · 巡查一个 B 站 UP 主的新视频，为每条新视频抓齐"可读材料"并生成草稿。
 *
 * 用法：
 *   node scripts/watch.mjs --mid 38061207 --vault "课程库" [--asr] [--max 3] [--dry-run]
 *
 * 职责边界：
 *   - 它只做确定性的事：列新视频 → 抓元信息/关键帧/（可选）转写 → 写 draft.md → 记 state。
 *   - 判断学科、写正式笔记、更新索引，由模型看 draft.md 之后做。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SKILL_ROOT = path.resolve(HERE, '..');
const VIDEO_MJS = path.join(HERE, 'video.mjs');
const NODE = process.execPath;

const H = {
  'user-agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  referer: 'https://space.bilibili.com/',
  accept: 'application/json, text/plain, */*',
};

// ---------------------------------------------------------------- 参数

function parseArgs(argv) {
  const a = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const k = argv[i].slice(2);
      const v = argv[i + 1];
      if (v && !v.startsWith('--')) {
        a[k] = v;
        i++;
      } else a[k] = true;
    } else a._.push(argv[i]);
  }
  return a;
}

// ---------------------------------------------------------------- wbi 签名

const MIXIN_TAB = [
  46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38,
  41, 13, 37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36,
  20, 34, 44, 52,
];

async function getMixinKey() {
  const r = await fetch('https://api.bilibili.com/x/web-interface/nav', { headers: H });
  const j = await r.json();
  const img = j.data?.wbi_img?.img_url || '';
  const sub = j.data?.wbi_img?.sub_url || '';
  const raw = [...img, ...sub]
    .map((u) => String(u).split('/').pop().split('.')[0])
    .join('');
  return MIXIN_TAB.map((i) => raw[i]).join('').slice(0, 32);
}

function signWbi(params, mixinKey) {
  const p = { ...params, wts: Math.floor(Date.now() / 1000) };
  const q = Object.keys(p)
    .sort()
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(String(p[k]))}`)
    .join('&');
  return `${q}&w_rid=${crypto.createHash('md5').update(q + mixinKey).digest('hex')}`;
}

// ---------------------------------------------------------------- 列视频

async function listBySpaceArc(mid, mixinKey) {
  const url = `https://api.bilibili.com/x/space/wbi/arc/search?${signWbi(
    { mid, ps: 30, pn: 1, order: 'pubdate', index: 0, platform: 'web' },
    mixinKey
  )}`;
  const r = await fetch(url, { headers: H });
  const j = await r.json();
  if (j.code !== 0) throw new Error(`wbi/arc ${j.code} ${j.message}`);
  return (j.data?.list?.vlist || []).map((v) => ({
    bvid: v.bvid,
    title: v.title,
    created: v.created,
    duration: v.length,
    plays: v.play,
  }));
}

async function listBySeasons(mid) {
  const r = await fetch(
    `https://api.bilibili.com/x/polymer/web-space/seasons_series_list?mid=${mid}&page_num=1&page_size=20`,
    { headers: H }
  );
  const j = await r.json();
  if (j.code !== 0) throw new Error(`seasons ${j.code} ${j.message}`);

  const il = j.data?.items_lists || {};
  const buckets = [...(il.seasons_list || []), ...(il.series_list || [])];
  const out = [];
  const seen = new Set();

  for (const b of buckets) {
    const meta = b.meta || {};
    const sid = meta.season_id;
    const rid = meta.series_id;
    const total = Number(meta.total || 0);
    if (!sid && !rid) continue;
    let pn = 1;
    for (;;) {
      const url = sid
        ? `https://api.bilibili.com/x/polymer/web-space/seasons_archives_list?mid=${mid}&season_id=${sid}&page_num=${pn}&page_size=30`
        : `https://api.bilibili.com/x/series/archives?mid=${mid}&series_id=${rid}&only_normal=true&sort=desc&pn=${pn}&ps=30`;
      const rr = await fetch(url, { headers: H });
      const jj = await rr.json();
      if (jj.code !== 0) break;
      const arcs = jj.data?.archives || [];
      for (const a of arcs) {
        const bvid = a.bvid;
        if (!bvid || seen.has(bvid)) continue;
        seen.add(bvid);
        out.push({
          bvid,
          title: a.title,
          created: a.pubdate,
          duration: a.duration,
          plays: a.stat?.view,
          season: meta.name || meta.title,
        });
      }
      const pageTotal = Number(jj.data?.page?.total || total || 0);
      if (!arcs.length || (pageTotal && pn * 30 >= pageTotal)) break;
      pn++;
      if (pn > 10) break; // 防呆，合集不可能超过 300 条
    }
  }
  return out;
}

async function listVideos(mid) {
  try {
    const key = await getMixinKey();
    const v = await listBySpaceArc(mid, key);
    if (v.length) return { source: 'wbi/arc/search', videos: v };
  } catch (e) {
    console.error(`[watch] wbi 接口不可用（${e.message}），退回合集接口`);
  }
  const v = await listBySeasons(mid);
  return { source: 'seasons', videos: v };
}

// ---------------------------------------------------------------- 学科初分

const DEFAULT_SUBJECTS = {
  'AI·工具': ['deepseek', 'harness', 'dsh', 'cursor', 'claude', 'codex', '工具', '插件', 'agent', '智能体'],
  'AI·内容生产': ['修图', '抠图', '视频', '漫剧', '绘图', '剪辑', '配音', '海报', '写真'],
  'AI·行业观察': ['商单', '职业', '行业', '赚钱', '自媒体', '裁员', '就业', '风口'],
  'AI·技术入门': ['python', 'opencv', '人脸识别', '教程', '入门', '编程', '写代码', 'vibe coding'],
};

/** 按标题关键词打分，返回学科名；没有命中就落到「待分类」 */
function classify(title, subjects = DEFAULT_SUBJECTS) {
  const t = String(title || '').toLowerCase();
  let best = null;
  let bestScore = 0;
  for (const [name, kws] of Object.entries(subjects)) {
    let score = 0;
    for (const kw of kws) if (t.includes(kw.toLowerCase())) score += 1;
    if (score > bestScore) {
      best = name;
      bestScore = score;
    }
  }
  return best || '待分类';
}

// ---------------------------------------------------------------- 抓材料

function runVideo(args) {
  const r = spawnSync(NODE, [VIDEO_MJS, ...args], { stdio: ['ignore', 'ignore', 'inherit'] });
  return r.status === 0;
}

async function collectOne(v, vault, opts, subject) {
  const dir = path.join(vault, '_inbox', v.bvid);
  await fs.mkdir(dir, { recursive: true });

  const base = ['--out', dir];
  const okInfo = runVideo(['info', v.bvid, ...base]);
  const okFrames = runVideo(['frames', v.bvid, '--every', String(opts.every), '--max', String(opts.max), ...base]);

  let asrNote = '未转写（加 --asr 可开）';
  if (opts.asr) {
    asrNote = runVideo(['asr', v.bvid, ...base]) ? '已转写 transcript.txt' : '转写失败';
  }

  const meta = JSON.parse(await fs.readFile(path.join(dir, 'meta.json'), 'utf8').catch(() => '{}'));
  const frames = JSON.parse(await fs.readFile(path.join(dir, 'frames.json'), 'utf8').catch(() => '{}'));

  const draft = [
    `# ${v.title}`,
    '',
    `- BV：${v.bvid}`,
    `- 时长：${meta.时长 || v.duration}`,
    `- 发布：${new Date((v.created || 0) * 1000).toISOString().slice(0, 10)}`,
    `- 播放：${v.plays ?? meta.播放 ?? '-'}`,
    `- 合集：${v.season || '（未归入合集）'}`,
    `- 初判学科：${subject}`,

    '',
    '## 材料',
    '',
    `- 元信息：meta.json`,
    `- 关键帧：${(frames.sheets || []).map((s) => s.file).join('、') || '（无）'}`,
    `- 语音：${asrNote}`,
    '',
    '## 待办（模型来写）',
    '',
    '- 读关键帧 → 提炼章节',
    '- 判断学科归属 → 移动到 学科/ 下',
    '- 更新 index.md',
  ].join('\n');

  await fs.writeFile(path.join(dir, 'draft.md'), draft, 'utf8');
  return { dir, okInfo, okFrames };
}

// ---------------------------------------------------------------- 主流程

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const mid = Number(args.mid);
  if (!mid) throw new Error('缺少 --mid');
  const vault = path.resolve(args.vault || '课程库');
  const opts = {
    asr: !!args.asr,
    every: Number(args.every || 60),
    max: Number(args.max || 48),
    limit: Number(args.limit || 3),
  };

  await fs.mkdir(vault, { recursive: true });
  const statePath = path.join(vault, '.state.json');
  const state = JSON.parse((await fs.readFile(statePath, 'utf8').catch(() => '{"seen":{}}')) || '{"seen":{}}');
  const subjectsRaw = await fs.readFile(path.join(vault, 'subjects.json'), 'utf8').catch(() => null);
  const subjects = subjectsRaw ? JSON.parse(subjectsRaw) : DEFAULT_SUBJECTS;

  // 子命令 list：只出列表 JSON，给 agent.mjs 用（沙箱里不能走管道，所以支持写文件）
  if (args._[0] === 'list') {
    const { source, videos } = await listVideos(mid);
    const payload = JSON.stringify({ source, videos }, null, 2);
    if (args['out-json']) await fs.writeFile(path.resolve(String(args['out-json'])), payload, 'utf8');
    else console.log(payload);
    return;
  }

  const { source, videos } = await listVideos(mid);
  const fresh = videos.filter((v) => v.bvid && !state.seen[v.bvid]).sort((a, b) => (a.created || 0) - (b.created || 0));

  const out = {
    接口: source,
    总数: videos.length,
    已有: Object.keys(state.seen).length,
    新发现: fresh.length,
    处理: [],
  };

  // 首次运行（state 为空）只建基线，不会把 185 条历史全抓一遍；
  // 但顺手把最新 limit 条处理掉，让第一次跑就有产出。
  const firstRun = Object.keys(state.seen).length === 0 && !args.force;
  const toProcess = firstRun ? fresh.slice(-opts.limit) : fresh.slice(0, opts.limit);
  if (firstRun) {
    for (const v of fresh) {
      if (toProcess.includes(v)) continue;
      state.seen[v.bvid] = { title: v.title, pubdate: v.created, baseline: true, at: new Date().toISOString() };
    }
    out.基线 = `首次运行，已把 ${Object.keys(state.seen).length} 条历史标为已读，只处理最新 ${toProcess.length} 条`;
  }

  if (args['dry-run']) {
    out.预览 = fresh.slice(0, 10).map((v) => ({ bvid: v.bvid, 标题: v.title, 发布: new Date((v.created || 0) * 1000).toISOString().slice(0, 10) }));
    console.log(JSON.stringify(out, null, 2));
    return;
  }

  for (const v of toProcess) {
    console.error(`[watch] 处理 ${v.bvid} ${v.title}`);
    const subject = classify(v.title, subjects);
    try {
      const r = await collectOne(v, vault, opts, subject);
      state.seen[v.bvid] = {
        title: v.title,
        pubdate: v.created,
        dir: path.relative(vault, r.dir),
        subject,
        at: new Date().toISOString(),
        ok: r.okInfo && r.okFrames,
      };
      out.处理.push({
        bvid: v.bvid,
        标题: v.title,
        学科: subject,
        草稿: path.join(r.dir, 'draft.md'),
        成功: r.okInfo && r.okFrames,
      });
    } catch (e) {
      console.error(`[watch] 失败 ${v.bvid}: ${e.message}`);
      out.处理.push({ bvid: v.bvid, 错误: e.message });
    }
  }

  await fs.writeFile(statePath, JSON.stringify(state, null, 2), 'utf8');
  console.log(JSON.stringify(out, null, 2));
}

main().catch((e) => {
  console.error('[watch][错误]', e.message);
  process.exit(1);
});
