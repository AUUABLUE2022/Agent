# 安装

两种方式，选一个。都假设你已经装了 **Node 20+**（DSH 用户不必另装，见下）。

## 方式 A：一键（推荐）

```powershell
# 在解压后的 video-agent 目录里
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

它会：复制到 `~/.dsh/skills/video-agent` → 装依赖 → 下语音模型（42 MB）→ 跑自检。

参数：

```powershell
.\install.ps1 -Target "D:\tools\video-agent"   # 换安装位置
.\install.ps1 -SkipModel                       # 先不下模型（只取帧/字幕）
```

## 方式 B：手动

```powershell
# 1. 放到技能目录（二选一）
Copy-Item . -Destination "$env:USERPROFILE\.dsh\skills\video-agent" -Recurse   # 全局
# 或：复制到 <你的项目>\.dsh\skills\video-agent                                # 仅该项目

# 2. 装依赖
cd "$env:USERPROFILE\.dsh\skills\video-agent"
npm install --omit=dev

# 3. 下模型（需要能访问 alphacephei.com 或 gh-proxy.com）
node scripts/setup-model.mjs

# 4. 自检
node scripts/doctor.mjs
```

DSH 用户找不到 `node` 时，用它自带的：

```powershell
$node = "C:\Users\<你>\AppData\Local\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
& $node .\scripts\doctor.mjs
```

## 自检没过的常见原因

| 现象 | 原因 | 修法 |
|---|---|---|
| `sharp` 加载失败 | 依赖没装在包目录里 | 在包目录执行 `npm install`，不要在别处装 |
| `vosk` 加载失败 | 缺 `libvosk.dll` | `node scripts/setup-model.mjs` |
| `中文模型 未安装` | 模型没下 | 同上；国内网络慢可换源，见下 |
| `网络 / B站接口 ✗` | 代理、防火墙、或接口风控 | 换网络；等 1–2 分钟再试 |
| `asr` 报 `does not contain model files` | 模型路径含中文 | 脚本已内置 `chdir` 绕过；若你自定义了 `--model`，注意同样的坑 |

## 模型下载慢怎么办

`setup-model.mjs` 里两个地址，可以自己换：

- `LIB_ZIP`：`gh-proxy.com` 镜像的 vosk Windows 库（含 `libvosk.dll`）
- `MODEL_ZIP`：`alphacephei.com` 官方的中文小模型（42 MB）

实测 alphacephei 在国内约 3.5 MB/分钟，15 分钟左右下完。嫌慢就找镜像，把 `MODEL_ZIP` 换成可用的 URL 再跑。

## 卸载

```powershell
Remove-Item "$env:USERPROFILE\.dsh\skills\video-agent" -Recurse -Force
```

没有注册表、没有后台服务，删目录即卸载。
