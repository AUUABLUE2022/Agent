# 课程库 · 索引

> 由 `video-learn` 技能自动巡查维护：新视频进 `_inbox/`，正式笔记归档到 `学科/`。
> 巡查目标：Git源宝（mid `38061207`）· 7 个合集 / 系列，共 185 条视频。

---

## AI·工具

| 笔记 | 来源 | 时长 | 归档日 |
|---|---|---|---|
| [DeepSeek Harness 超详细教程](学科/AI·工具/DeepSeek-Harness超详细教程.md) | [BV1REx46NEc4](https://www.bilibili.com/video/BV1REx46NEc4/) | 50:41 | 2026-11-02 |

## AI·内容生产

（暂无）

## AI·行业观察

（暂无）

## AI·技术入门

（暂无）

---

## 工作方式

```powershell
# 1) 巡查（首次会建基线，只抓最新几条；之后只抓增量）
node scripts/watch.mjs --mid 38061207 --vault "课程库" --limit 3

# 2) 看 _inbox/<BV>/draft.md，读联系表，写正式笔记到 学科/<学科>/，更新本索引
```

## 状态

- 已读基线：185 条（`_inbox/.state.json`）
- 待处理草稿：0
- 上次巡查：2026-11-02
