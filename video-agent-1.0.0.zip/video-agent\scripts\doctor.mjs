#!/usr/bin/env node
/**
 * 自检：这个 Agent 在这台机器上能不能跑。
 * 用法：node scripts/doctor.mjs
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const rows = [];
const ok = (name, detail) => rows.push({ 检查: name, 结果: '✓', 说明: detail });
const bad = (name, detail, fix) => rows.push({ 检查: name, 结果: '✗', 说明: detail, 修复: fix });
const warn = (name, detail) => rows.push({ 检查: name, 结果: '!', 说明: detail });

async function main() {
  // node
  const major = Number(process.versions.node.split('.')[0]);
  major >= 20 ? ok('node', `v${process.versions.node}`) : bad('node', `v${process.versions.node} 太旧`, '装 Node 20+');

  // 脚本
  for (const f of ['video.mjs', 'watch.mjs', 'setup-model.mjs']) {
    try {
      await fs.access(path.join(ROOT, 'scripts', f));
      ok(`脚本 ${f}`, '存在');
    } catch {
      bad(`脚本 ${f}`, '缺失', '重新解压完整包');
    }
  }

  // sharp
  try {
    const sharp = require('sharp');
    ok('sharp', `libvips ${sharp.versions.vips}`);
  } catch (e) {
    bad('sharp', e.message.slice(0, 60), '在包目录执行 npm install');
  }

  // ffmpeg
  try {
    const ff = require('@ffmpeg-installer/ffmpeg').path;
    const r = spawnSync(ff, ['-version'], { stdio: 'ignore' });
    r.status === 0 ? ok('ffmpeg', path.basename(ff)) : bad('ffmpeg', `退出码 ${r.status}`, '重装依赖');
  } catch (e) {
    bad('ffmpeg', e.message.slice(0, 60), '在包目录执行 npm install');
  }

  // vosk + dll
  try {
    require('vosk');
    const dll = path.join(ROOT, 'node_modules', 'vosk', 'lib', 'win-x86_64', 'libvosk.dll');
    await fs.access(dll);
    ok('vosk', 'libvosk.dll 就位');
  } catch {
    bad('vosk', '加载失败或缺 libvosk.dll', 'node scripts/setup-model.mjs');
  }

  // 模型
  const model = path.join(ROOT, 'models', 'vosk-model-small-cn-0.22', 'am', 'final.mdl');
  (await fs.stat(model).catch(() => null))
    ? ok('中文模型', 'vosk-model-small-cn-0.22')
    : warn('中文模型', '未安装（asr 会不可用）', 'node scripts/setup-model.mjs');

  // 网络
  try {
    const ctl = AbortSignal.timeout(15000);
    const r = await fetch('https://api.bilibili.com/x/web-interface/view?bvid=BV1REx46NEc4', { signal: ctl });
    const j = await r.json();
    j.code === 0 ? ok('网络 / B站接口', j.data.title.slice(0, 24) + '…') : bad('网络 / B站接口', `code ${j.code}`, '换网络或加 cookie');
  } catch (e) {
    bad('网络 / B站接口', String(e.message).slice(0, 50), '检查代理/防火墙');
  }

  // 打印
  const pad = (s, n) => String(s).padEnd(n, ' ');
  console.log('');
  console.log(pad('项目', 20) + pad('结果', 4) + '说明');
  console.log('-'.repeat(64));
  for (const r of rows) {
    console.log(pad(r.检查, 20) + pad(r.结果, 4) + r.说明);
    if (r.修复) console.log(pad('', 24) + '↳ 修复：' + r.修复);
  }
  const failed = rows.filter((r) => r.结果 === '✗').length;
  const warns = rows.filter((r) => r.结果 === '!').length;
  console.log('');
  if (failed) console.log(`有 ${failed} 项没通过，先修完再用。`);
  else if (warns) console.log(`可用（${warns} 项提醒：语音转写要装模型，其余功能正常）。`);
  else console.log('全部通过，可以开工。');
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error('自检本身出错了：', e.message);
  process.exit(1);
});
