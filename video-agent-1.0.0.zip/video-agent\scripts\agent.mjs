#!/usr/bin/env node
/**
 * video-agent 的自主循环。
 *
 * 它自己决定这条视频走到哪一步、要不要重试、够不够格归档；
 * 只有"写得多好"这一件事留给模型（见 note.md 里的「待校订」）。
 *
 * 用法：
 *   node scripts/agent.mjs run    [--vault 目录] [--limit N] [--asr|--no-asr] [--force BV]
 *   node scripts/agent.mjs status [--vault 目录]
 *   node scripts/agent.mjs watch  [--vault 目录] [--interval 分钟]   # 常驻循环
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SCRIPTS = HERE;
const NODE = process.execPath;
const VIDEO = path.join(SCRIPTS, 'video.mjs');

// ---------------------------------------------------------------- 工具

function parseArgs(argv) {
  const a = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith('--')) {
      const k = t.slice(2);
      const v = argv[i + 1];
      if (v && !v.startsWith('--')) {
        a[k] = v;
        i++;
      } else a[k] = true;
    } else a._.push(t);
  }
  return a;
}

const log = (...m) => console.error(`[${new Date().toISOString().slice(11, 19)}]`, ...m);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fmt = (s) => {
  const n = Math.max(0, Math.round(s || 0));
  const h = Math.floor(n / 3600);
  const m = Math.floor((n % 3600) / 60);
  const ss = String(n % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${String(m).padStart(2, '0')}:${ss}`;
};
const safeName = (s) =>
  String(s)
    .replace(/[\\/:*?"<>|]/g, '-')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60);

async function readJSON(p, fallback) {
  try {
    return JSON.parse(await fs.readFile(p, 'utf8'));
  } catch {
    return fallback;
  }
}

async function writeJSON(p, v) {
  await fs.mkdir(path.dirname(p), { recursive: true });
  await fs.writeFile(p, JSON.stringify(v, null, 2), 'utf8');
}

// ---------------------------------------------------------------- 配置

const DEFAULT_CONFIG = {
  vault: '课程库',
  targets: [],
  asr: true,
  frames: { every: 60, max: 48 },
  limits: { perRun: 2, retries: 2, maxMinutes: 45 },
  note: { maxTimeline: 80 },
};

async function loadConfig(args) {
  const cfgPath = path.join(HERE, '..', 'agent.config.json');
  const cfg = { ...DEFAULT_CONFIG, ...(await readJSON(cfgPath, {})) };
  if (args.vault) cfg.vault = args.vault;
  if (args.limit) cfg.limits.perRun = Number(args.limit);
  if (args.asr) cfg.asr = true;
  if (args['no-asr']) cfg.asr = false;
  cfg.vaultPath = path.resolve(cfg.vault);
  cfg.statePath = path.join(cfg.vaultPath, '.agent-state.json');
  cfg.indexPath = path.join(cfg.vaultPath, 'index.json');
  return cfg;
}

// ---------------------------------------------------------------- 采集

function runVideo(args, label, { optional = false } = {}) {
  log(`  ↳ ${label}`);
  const r = spawnSync(NODE, [VIDEO, ...args], { stdio: ['ignore', 'ignore', 'inherit'] });
  if (r.status !== 0) {
    if (optional) {
      log(`  ↳ ${label} 跳过（退出码 ${r.status}）`);
      return false;
    }
    throw new Error(`${label} 失败（退出码 ${r.status}）`);
  }
  return true;
}

async function collect(cfg, video, dir) {
  runVideo(['info', video.bvid, '--out', dir], 'info');
  if (!cfg.frames?.skip) {
    runVideo(
      ['frames', video.bvid, '--every', String(cfg.frames.every), '--max', String(cfg.frames.max), '--out', dir],
      'frames'
    );
  }
  // 转写失败不致命：没转写也能出"画面版"笔记
  if (cfg.asr) return runVideo(['asr', video.bvid, '--out', dir], 'asr', { optional: true });
  return false;
}

// ---------------------------------------------------------------- 写笔记

/** 按时间间隔切章节：停顿超过 gap 秒就断一刀，给个朴素的小标题 */
function outline(segs, gap = 25) {
  const chapters = [];
  let cur = null;
  for (const s of segs) {
    if (!cur || s.t - cur.end > gap) {
      cur = { start: s.t, end: s.t, lines: [] };
      chapters.push(cur);
    }
    cur.lines.push(s);
    cur.end = s.t;
  }
  return chapters;
}

async function composeNote(cfg, video, dir, subject) {
  const meta = await readJSON(path.join(dir, 'meta.json'), {});
  const frames = await readJSON(path.join(dir, 'frames.json'), {});
  const segs = await readJSON(path.join(dir, 'asr.json'), []);

  const rel = (p) => path.relative(path.join(cfg.vaultPath, '学科', subject), p).replace(/\\/g, '/');
  const sheets = (frames.sheets || []).map((s) => rel(path.join(dir, s.file)));
  const transcript = (await fs.readFile(path.join(dir, 'transcript.txt'), 'utf8').catch(() => '')).trim();

  const lines = [];
  lines.push(`# ${meta.标题 || video.title}`);
  lines.push('');
  lines.push(`| | |`);
  lines.push(`|---|---|`);
  lines.push(`| 来源 | https://www.bilibili.com/video/${video.bvid}/ |`);
  lines.push(`| UP 主 | ${meta.UP主 || '-'} · ${meta.时长 || fmt(video.duration)} |`);
  lines.push(`| 合集 | ${video.season || '（散视频）'} |`);
  lines.push(`| 发布 | ${(meta.发布时间 || '').slice(0, 10)} |`);
  lines.push(`| 学科 | ${subject}（关键词初判） |`);
  lines.push(`| 采集 | 关键帧 ${(frames.frames || []).length} 张 / 转写 ${segs.length} 段 |`);
  lines.push('');
  lines.push('> 本文由 video-agent 自动生成：画面采样 + 本地转写，**未经模型校订**。');
  lines.push('> 转写只可信大意，专有名词常错；引用原话请用官方字幕。');
  lines.push('');

  if (sheets.length) {
    lines.push('## 画面');
    lines.push('');
    for (const s of sheets) lines.push(`![${path.basename(s)}](${s})`);
    lines.push('');
  }

  if (transcript) {
    lines.push('## 时间轴');
    lines.push('');
    const max = cfg.note.maxTimeline;
    if (segs.length && segs.length <= max) {
      for (const c of outline(segs)) {
        lines.push(`### ${fmt(c.start)} – ${fmt(c.end)}`);
        lines.push('');
        lines.push(c.lines.map((x) => x.text).join(''));
        lines.push('');
      }
    } else {
      for (const s of segs.slice(0, max)) lines.push(`- \`${fmt(s.t)}\` ${s.text}`);
      if (segs.length > max) lines.push(`\n（转写共 ${segs.length} 段，此处只列前 ${max} 段，全文见 \`transcript.txt\`）`);
      lines.push('');
    }
  } else {
    lines.push('## 时间轴');
    lines.push('');
    lines.push('（未转写：本次运行关闭了 asr，或音频不可用）');
    lines.push('');
  }

  lines.push('## 待校订');
  lines.push('');
  lines.push(`- 学科初判为「${subject}」，按标题关键词打分，可能偏；需要模型/人复核一次。`);
  lines.push(`- 原始材料在 \`${path.relative(cfg.vaultPath, dir).replace(/\\/g, '/')}/\`。`);
  return lines.join('\n');
}

// ---------------------------------------------------------------- 分类

async function classify(cfg, title) {
  const subjects = await readJSON(path.join(cfg.vaultPath, 'subjects.json'), null);
  if (!subjects) return { subject: '待分类', score: 0 };
  const t = String(title || '').toLowerCase();
  let best = '待分类';
  let bestScore = 0;
  for (const [name, kws] of Object.entries(subjects)) {
    const score = kws.filter((k) => t.includes(String(k).toLowerCase())).length;
    if (score > bestScore) {
      best = name;
      bestScore = score;
    }
  }
  return { subject: best, score: bestScore };
}

// ---------------------------------------------------------------- 索引

async function refreshIndex(cfg) {
  const list = await readJSON(cfg.indexPath, { items: [] });
  const rows = list.items.slice().sort((a, b) => (b.pubdate || 0) - (a.pubdate || 0));
  const bySubject = new Map();
  for (const r of rows) {
    if (!bySubject.has(r.subject)) bySubject.set(r.subject, []);
    bySubject.get(r.subject).push(r);
  }
  const out = [];
  out.push('# 课程库 · 索引');
  out.push('');
  out.push('> 由 video-agent 自动维护。新视频进 `_inbox/`，笔记归档到 `学科/`。');
  out.push(`> 已归档 ${rows.length} 条 · 更新于 ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`);
  out.push('');
  for (const [subject, items] of bySubject) {
    out.push(`## ${subject}`);
    out.push('');
    out.push('| 笔记 | 来源 | 时长 | 发布 |');
    out.push('|---|---|---|---|');
    for (const it of items) {
      const link = path.relative(cfg.vaultPath, path.join(cfg.vaultPath, it.note)).replace(/\\/g, '/');
      out.push(`| [${it.title.replace(/\|/g, '\\|')}](${link}) | [${it.bvid}](https://www.bilibili.com/video/${it.bvid}/) | ${it.duration} | ${it.pubdate || '-'} |`);
    }
    out.push('');
  }
  await fs.mkdir(cfg.vaultPath, { recursive: true });
  await fs.writeFile(path.join(cfg.vaultPath, 'index.md'), out.join('\n'), 'utf8');
}

// ---------------------------------------------------------------- 主流程：run

async function runOnce(cfg, args) {
  const state = await readJSON(cfg.statePath, { items: {}, runs: 0 });
  state.runs = (state.runs || 0) + 1;

  // 从 watch.mjs 的旧基线迁移，避免把历史视频重跑一遍
  if (Object.keys(state.items).length === 0) {
    const legacy = await readJSON(path.join(cfg.vaultPath, '.state.json'), null);
    if (legacy?.seen) {
      for (const [bvid, v] of Object.entries(legacy.seen)) {
        state.items[bvid] = { stage: 'skipped', reason: '继承 watch.mjs 基线', title: v.title, at: v.at };
      }
      log(`继承旧基线 ${Object.keys(legacy.seen).length} 条`);
    }
  }

  // 1) 列新视频
  const pending = [];
  if (args.force) {
    pending.push({ bvid: String(args.force), title: '(强制处理)', duration: 0, season: '' });
  } else {
    const { listVideos } = await loadLister(cfg);
    for (const t of cfg.targets) {
      try {
        const { source, videos } = await listVideos(t.mid);
        log(`目标 ${t.name || t.mid}：${videos.length} 条（${source}）`);
        for (const v of videos) {
          if (!v.bvid || state.items[v.bvid]) continue;
          pending.push(v);
        }
      } catch (e) {
        log(`目标 ${t.name || t.mid} 拉列表失败：${e.message}`);
      }
    }
    // 首次运行：全部标成跳过，只留最新 limit 条
    const unseen = pending.filter((v) => !state.items[v.bvid]);
    if (state.runs === 1 && unseen.length > cfg.limits.perRun) {
      unseen.sort((a, b) => (a.created || 0) - (b.created || 0));
      const keep = unseen.slice(-cfg.limits.perRun);
      for (const v of unseen) {
        if (keep.includes(v)) continue;
        state.items[v.bvid] = { stage: 'skipped', reason: '首次运行基线', at: new Date().toISOString() };
      }
      pending.length = 0;
      pending.push(...keep);
    }
  }

  // 上轮失败的重新排队（stage=retry），否则它们会永远卡在状态里
  for (const [bvid, rec] of Object.entries(state.items)) {
    if (rec.stage !== 'retry') continue;
    if (pending.some((p) => p.bvid === bvid)) continue;
    pending.push({ bvid, title: rec.title || '(重试)', duration: 0, season: '', created: 0 });
  }

  const todo = pending.slice(0, cfg.limits.perRun);
  const result = { run: state.runs, queued: pending.length, done: [], failed: [], skipped: [] };

  if (!todo.length) {
    log('没有新视频。');
    await writeJSON(cfg.statePath, state);
    return result;
  }

  for (const v of todo) {
    const rec = state.items[v.bvid] || { attempts: 0 };
    state.items[v.bvid] = rec;
    rec.attempts = (rec.attempts || 0) + 1;
    const dir = path.join(cfg.vaultPath, '_inbox', v.bvid);

    try {
      log(`处理 ${v.bvid} ${v.title}（第 ${rec.attempts} 次）`);
      const started = Date.now();
      await collect(cfg, v, dir);
      // 转写完成后清掉中间音频，别让 _inbox 无限膨胀（保留可查的证据：transcript/asr.json/sheets）
      if (cfg.cleanupAudio !== false) {
        for (const f of ['audio-16k.wav', 'audio.m4a']) await fs.rm(path.join(dir, f), { force: true });
      }
      const meta = await readJSON(path.join(dir, 'meta.json'), {});
      const title = meta.标题 || v.title;
      const { subject, score } = await classify(cfg, title);

      const noteRel = path.join('学科', subject, `${safeName(title)}-${v.bvid}.md`);
      const noteAbs = path.join(cfg.vaultPath, noteRel);
      await fs.mkdir(path.dirname(noteAbs), { recursive: true });
      await fs.writeFile(noteAbs, await composeNote(cfg, { ...v, title }, dir, subject), 'utf8');

      const idx = await readJSON(cfg.indexPath, { items: [] });
      idx.items = idx.items.filter((x) => x.bvid !== v.bvid);
      idx.items.push({
        bvid: v.bvid,
        title,
        subject,
        note: noteRel.replace(/\\/g, '/'),
        duration: meta.时长 || fmt(v.duration),
        pubdate: (meta.发布时间 || '').slice(0, 10),
      });
      await writeJSON(cfg.indexPath, idx);
      await refreshIndex(cfg);

      Object.assign(rec, {
        stage: 'done',
        title,
        subject,
        note: noteRel.replace(/\\/g, '/'),
        reason: '',
        seconds: Math.round((Date.now() - started) / 1000),
        at: new Date().toISOString(),
      });
      result.done.push({ bvid: v.bvid, subject, note: rec.note, 秒: rec.seconds });
      log(`  ✓ 归档到 ${rec.note}（${rec.seconds}s）`);
    } catch (e) {
      const willRetry = rec.attempts < cfg.limits.retries;
      Object.assign(rec, {
        stage: willRetry ? 'retry' : 'failed',
        reason: e.message,
        at: new Date().toISOString(),
      });
      result.failed.push({ bvid: v.bvid, 错误: e.message, 下次重试: willRetry });
      log(`  ✗ ${e.message}${willRetry ? '（下轮重试）' : '（放弃）'}`);
    }
    await writeJSON(cfg.statePath, state);
  }

  await writeJSON(cfg.statePath, state);
  return result;
}

// 通过 watch.mjs 的 list 子命令拿视频列表。
// 注意：沙箱里子进程不能用管道 stdio，所以让它把 JSON 写到文件再读。
async function loadLister(cfg) {
  const tmp = path.join(cfg.vaultPath, '.list.json');
  return {
    listVideos: async (mid) => {
      await fs.rm(tmp, { force: true });
      const r = spawnSync(NODE, [path.join(SCRIPTS, 'watch.mjs'), 'list', '--mid', String(mid), '--out-json', tmp], {
        stdio: 'ignore',
      });
      if (r.status !== 0) throw new Error(`list 退出码 ${r.status}`);
      const data = JSON.parse(await fs.readFile(tmp, 'utf8'));
      await fs.rm(tmp, { force: true });
      return data;
    },
  };
}

// ---------------------------------------------------------------- status / watch

async function status(cfg) {
  const state = await readJSON(cfg.statePath, { items: {}, runs: 0 });
  const items = Object.entries(state.items);
  const by = (s) => items.filter(([, v]) => v.stage === s);
  console.log(
    JSON.stringify(
      {
        仓库: cfg.vaultPath,
        运行次数: state.runs,
        条目: items.length,
        完成: by('done').length,
        失败: by('failed').length,
        待重试: by('retry').length,
        跳过: by('skipped').length,
        最近完成: by('done')
          .sort((a, b) => String(b[1].at).localeCompare(String(a[1].at)))
          .slice(0, 3)
          .map(([bvid, v]) => ({ bvid, 标题: v.title, 笔记: v.note })),
      },
      null,
      2
    )
  );
}

async function watchLoop(cfg, args) {
  const minutes = Number(args.interval || 60);
  log(`常驻模式：每 ${minutes} 分钟跑一轮，Ctrl+C 退出`);
  for (;;) {
    try {
      const r = await runOnce(cfg, args);
      log(`本轮：完成 ${r.done.length}，失败 ${r.failed.length}，排队 ${r.queued}`);
    } catch (e) {
      log(`本轮异常：${e.message}`);
    }
    await sleep(minutes * 60 * 1000);
  }
}

// ---------------------------------------------------------------- main

const args = parseArgs(process.argv.slice(2));
const cmd = args._[0] || 'run';
const cfg = await loadConfig(args);

if (cmd === 'run') console.log(JSON.stringify(await runOnce(cfg, args), null, 2));
else if (cmd === 'status') await status(cfg);
else if (cmd === 'watch') await watchLoop(cfg, args);
else {
  console.error('用法：agent.mjs run|status|watch [--vault 目录] [--limit N] [--force BV] [--asr|--no-asr] [--interval 分钟]');
  process.exit(2);
}
