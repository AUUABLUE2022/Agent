# 触发器一：Windows 任务计划（不需要 DSH 开着）

把这个 Agent 变成真正的后台常驻：系统定时叫它跑一轮，跑完自己退出。适合"每天下班前看一遍有没有新视频"。

```powershell
# 注册：每 6 小时跑一次
powershell -ExecutionPolicy Bypass -File .\triggers\register-task.ps1 -Hours 6

# 立刻跑一次试试
Start-ScheduledTask -TaskName VideoAgent

# 看运行记录
Get-ScheduledTaskInfo -TaskName VideoAgent
Get-Content .\triggers\agent.log -Tail 30

# 注销
.\triggers\register-task.ps1 -Unregister
```

注意：

- 默认「仅在用户登录时运行」，因为要读你的用户目录、写工作区。想真正无人值守（不登录也跑）需要提权并改成 `-RunLevel Highest` + 存储凭据，这里不默认做。
- 任务计划的进程没有 DSH 的沙箱，也就没有 `EPERM` 那套限制——但它同样没有模型，只能产出"自动版"笔记（画面 + 时间轴），写作质量靠模板。
- 日志写在 `triggers\agent.log`。

# 触发器二：常驻循环

不想用任务计划就让它自己循环：

```powershell
node scripts/agent.mjs watch --interval 120     # 每 2 小时一轮
```

Ctrl+C 退出。适合放在一个开着不关的终端里。

# 触发器三：DSH 会话内（能带模型）

`triggers/dsh-schedule.md` 是给 DSH `schedule_create` 用的提示词模板。这条路的差别是：**它会跑在一个有模型的会话里**，所以除了抓材料，还能让模型复核学科、改写成真正可读的笔记。

```text
每周一 09:00 跑一次，prompt 用 dsh-schedule.md 里的内容
```

# 三条路怎么选

| 你想要 | 用哪个 |
|---|---|
| 不用开着任何东西 | 任务计划 |
| 开着终端就行 | `watch` 常驻 |
| 笔记要"能读"，不只是能查 | DSH 定时（带模型） |
