# 发布清单

这个目录已经是可直接上传的仓库内容。下面是照抄就行的一页。

## 仓库信息

**名称**：`video-agent`
**一句话**：让 Agent 真的"看完"一个视频——关键帧 + 本地转写 + 定时巡查归档，一个技能包搞定。
**描述（GitHub/Gitee 填这个）**：

> Turn any web video into readable material for an LLM agent: timestamped keyframe contact sheets, offline Chinese speech-to-text, and a scheduled "follow & archive" pipeline. DSH skill bundle.

**Topics / 标签**：

```
deepseek-harness  dsh  skill  agent  bilibili  speech-to-text  vosk  video-summary  llm-tools
```

**License**：MIT

## 上传（Gitee，网络可达）

```powershell
cd release\video-agent
git init
git add .
git commit -m "feat: video-agent v0.3.0 - 看视频/听视频/定时归档"
git branch -M main
git remote add origin https://gitee.com/<你的用户名>/video-agent.git
git push -u origin main
git tag v0.3.0
git push origin v0.3.0
```

GitHub（需要先解决网络）：

```powershell
git remote add origin https://github.com/<你的用户名>/video-agent.git
git push -u origin main --tags
```

## Release 文案（可直接粘贴）

**v0.3.0 — 第一次发布**

能干什么：

- `video.mjs info/frames`：B 站视频 → 带 `mm:ss` 时间码的关键帧联系表，21 分钟视频 5 张图、10 秒生成
- `video.mjs asr`：本地 vosk 中文模型离线转写，3.6× 实时，不联网、不需要 API key
- `video.mjs subs`：有登录态时直接下官方字幕（可选）
- `watch.mjs`：巡查一个 UP 主的合集/系列，增量抓材料、生成草稿，幂等
- `doctor.mjs`：一条命令自检依赖、模型、网络

已知限制：缩略图 160×90 读不清小字；小模型专有名词识别差；不在合集里的散视频会漏。

附件：`video-agent-0.3.0.zip`（源码，不含 node_modules 与模型）

## 发布前自查（都已过）

- [x] `node scripts/doctor.mjs` 全绿
- [x] 脚本在真实环境跑通：50 分钟视频取帧 + 转写、185 条视频巡查
- [x] README 有实测数据，不是估计
- [x] 边界写得直白，不吹"完美转写"
- [x] 无硬编码的个人路径（`SKILL.md` 里的 node 路径写成了占位符）
- [x] `.gitignore` 排掉 `node_modules/`、`models/`、`bili-sessdata.txt`
- [x] 没有把任何 cookie / 密钥带进包里

## 发布后可以做的

1. 在 DSH 里 `git clone` 到 `~/.dsh/skills/`，跑 `install.ps1`，验证陌生人视角能不能装上——这一步最容易暴露 README 的坑。
2. 收一两个 issue 后，把 `watch.mjs` 的"合集之外抓不到"补掉（需要 wbi 签名 + cookie）。
3. 想上 DSH 插件市场的话，得再包一层 cordis 插件（`package.json` + `cordis.patch.yml` + 图标 + 双语 README），这份代码可以作为 `resources` 原样复用。
